const BulletType = Object.freeze({
    BULLET1: 0
});