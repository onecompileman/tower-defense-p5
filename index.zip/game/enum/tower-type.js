const TowerType = Object.freeze({
    TOWER1: 0
});