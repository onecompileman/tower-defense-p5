const EnemyType = Object.freeze({
    ENEMY1: 0
});